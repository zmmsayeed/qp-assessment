import { Request, Response } from 'express';
import db from '../models';

class GroceryController {
    private groceryItems = db.groceryItems;

    public async addGroceryItem(req: Request, res: Response): Promise<void> {
      console.log(this.groceryItems)
        try {
            const { name, price, inventoryCount } = req.body;
            const item = await this.groceryItems.create({ name, price, inventoryCount });
            res.status(201).send({
              successful: true,
              item
            });
        } catch (error: any) {
            res.status(500).send({
                successful: false,
                message: error.message
            });
        }
    }

    public async viewGroceryItems(req: Request, res: Response): Promise<void> {
        try {
            const items = await this.groceryItems.findAll();
            res.status(200).send({
              successful: true,
              items
            });
        } catch (error: any) {
            res.status(500).send({
                successful: false,
                message: error.message
            });
        }
    }

    public async updateGroceryItem(req: Request, res: Response): Promise<void> {
        try {
            const { id } = req.params;
            const { name, price, inventoryCount } = req.body;
            const item = await this.groceryItems.update({ name, price, inventoryCount }, { where: { id } });
            res.status(200).send({
              successful: true,
              message: `Updated ${item} record(s)`
            });
        } catch (error: any) {
            res.status(500).send({
                successful: false,
                message: error.message
            });
        }
    }

    public async deleteGroceryItem(req: Request, res: Response): Promise<void> {
        try {
            const { id } = req.params;
            await this.groceryItems.destroy({ where: { id } });
            res.status(200).send({
              successful: true,
              message: `Item deleted!`
            });
        } catch (error: any) {
            res.status(500).send({
                successful: false,
                message: error.message
            });
        }
    }
}

export default new GroceryController();
