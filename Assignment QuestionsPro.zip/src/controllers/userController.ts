import { Request, Response } from 'express';
import db from '../models';

class GroceryController {
    private groceryItems = db.groceryItems;

    public async listAvailableItems(req: Request, res: Response): Promise<void> {
        try {
            const items = await this.groceryItems.findAll({
                where: {
                    inventoryCount: {
                        [db.Sequelize.Op.gt]: 0
                    }
                }
            });
            res.status(200).send({
              successful: true,
              items
            });
        } catch (error: any) {
            res.status(500).send({
              successful: false,
              message: error.message
            });
        }
    }

    public async bookItems(req: Request, res: Response): Promise<void> {
        console.log("Entering the book items function");
        try {
            const { items } = req.body;
            const results = [];

            for (const item of items) {
                const { id, quantity } = item;
                const product = await this.groceryItems.findOne({ where: { id } });

                if (product && product.inventoryCount >= quantity) {
                    await this.groceryItems.update(
                        { inventoryCount: db.Sequelize.literal(`inventoryCount - ${quantity}`) },
                        { where: { id } }
                    );
                    results.push({ id, status: 'Booked', bookedQuantity: quantity });
                } else {
                    results.push({ id, status: 'Not enough inventory' });
                }
            }

            res.status(200).send({
              successful: true,
              results
            });
        } catch (error: any) {
            res.status(500).send({
                successful: false,
                message: error.message
            });
        }
    }
}

export default new GroceryController();
